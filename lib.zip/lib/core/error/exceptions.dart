class ServerException implements Exception {}

class NotfoundException implements Exception {}

class OfflineException implements Exception {}

class EmptyCacheException implements Exception {}
