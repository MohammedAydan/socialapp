 // const SizedBox(height: 10),
                      // Padding(
                      //   padding: const EdgeInsets.symmetric(horizontal: 20),
                      //   child: Row(
                      //     children: [
                      //       Expanded(
                      //         child: CustomPrimaryButton(
                      //             text: "Accept", onPressed: () {}),
                      //       ),
                      //       const SizedBox(width: 10),
                      //       Expanded(
                      //         child: CustomPrimaryButton(
                      //           text: "Reject",
                      //           onPressed: () {},
                      //           bgColor: context.theme.colorScheme.secondary,
                      //         ),
                      //       ),
                      //     ],
                      //   ),
                      // ),
                      // const SizedBox(height: 10),
                      // Padding(
                      //   padding: const EdgeInsets.symmetric(horizontal: 20),
                      //   child: Row(
                      //     children: [
                      //       Expanded(
                      //         child: CustomPrimaryButton(
                      //           text: "Cancel request",
                      //           onPressed: () {},
                      //           bgColor: context.theme.colorScheme.secondary,
                      //         ),
                      //       ),
                      //     ],
                      //   ),
                      // ),
                      // const SizedBox(height: 10),
                      // Padding(
                      //   padding: const EdgeInsets.symmetric(horizontal: 20),
                      //   child: Row(
                      //     children: [
                      //       Expanded(
                      //         child: CustomPrimaryButton(
                      //           text: "Unfollow",
                      //           onPressed: () {},
                      //           bgColor: context.theme.colorScheme.secondary,
                      //         ),
                      //       ),
                      //     ],
                      //   ),
                      // ),