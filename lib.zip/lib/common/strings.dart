// const String SUPABASE_URL = "SUPABASE_URL";
// const String SUPABASE_KEY = "SUPABASE_KEY";
// const String ONESIGNAL_KEY = "ONESIGNAL_KEY";

const String SUPABASE_URL = "https://bgtcdrsoxqppbymwwplx.supabase.co";
const String SUPABASE_KEY =
    "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJndGNkcnNveHFwcGJ5bXd3cGx4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3MTkyNDkxNjgsImV4cCI6MjAzNDgyNTE2OH0.O7r8Chm2xjF-s-J9UW5kQE85cSlIPr9X_UiX1UvIm-o";
const ONESIGNAL_KEY = "32a93ffd-b7e5-4a4b-86a5-521d6a6e8500";
