import 'package:flutter/material.dart';

class AppColors {
	static final Color baseColor = Color(0xFF212735);
}
