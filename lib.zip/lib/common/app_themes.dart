class AppThemes {
	//static final ThemeData appTheme = ThemeData()
}
