import 'package:flutter/material.dart';

class AppTextStyle {
	/*static TextStyle getAppTextStyle(
		{double size = 14,
		FontWeight weight = FontWeight.normal,
		FontStyle style = FontStyle.normal,
		Color color = Colors.black}) {
	  return TextStyle(
		  color: color,
		  fontSize: size,
		  fontWeight: weight,
		  fontStyle: style,
		  fontFamily: "Jost"
	}*/
}
