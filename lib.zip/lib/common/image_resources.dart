class ImageResources {
	//static final String loginBackground = "assets/images/bg.png";
}
